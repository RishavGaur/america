<?php
    $conn= mysqli_connect("localhost", "root", "", "america") or die("Connection Failed".mysqli_connect_error());
?>